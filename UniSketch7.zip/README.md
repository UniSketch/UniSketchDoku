# UniSketchDoku
Command to compile the document:

``` latexmk -shell-escape -pdf main.tex ```

